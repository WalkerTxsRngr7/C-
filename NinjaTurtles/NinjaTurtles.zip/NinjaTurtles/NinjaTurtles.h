#include <iostream>
using namespace std;

class NinjaTurtles
{
    public:
        string name;
        string color;
    
    
    
    NinjaTurtles(string strName, string strColor)
    {
        name = strName;
        color = strColor;
    }

    NinjaTurtles(){}

    string toString()
    {
        return "My name is " + name + " and I wear " + color + "\n";
    }
    
    
};
